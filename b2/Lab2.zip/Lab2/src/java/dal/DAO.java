/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Account;
import model.Employee;

/**
 *
 * @author admin
 */
public class DAO extends DBContext {

    public Account checkLogin(String username, String password) {

        String sql = "select username, password\n"
                + "from Account\n"
                + "where username = '" + username + "' and password = '" + password + "'";

        Account account = null;

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Account(username, password, null);
            }

            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return null;
    }

    public List<Employee> getEmployeesByCreator(String creatorName) {

        String sql = "select empid, empname, empdob, empgender\n"
                + "from Employee e, Account a\n"
                + "where username = createdby and displayName = '" + creatorName + "'";

        Employee employee = null;
        List<Employee> list = new ArrayList<>();

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String gender;
                if (rs.getInt(4) == 1) {
                    gender = "Male";
                } else {
                    gender = "Female";
                }
                employee = new Employee(rs.getInt(1), rs.getString(2), rs.getDate(3),
                        gender);
                list.add(employee);
            }

            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return list;
    }

    public List<String> getAccountsNames() {

        String sql = "select displayName\n"
                + "from Account";

        List<String> list = new ArrayList<>();

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String name = rs.getString(1);
                list.add(name);
            }

            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return list;
    }

    public List<String> getCertificateNames() {

        String sql = "select *\n"
                + "from Certificate";

        List<String> list = new ArrayList<>();

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String name = rs.getString(2);
                list.add(name);
            }

            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return list;
    }

}
